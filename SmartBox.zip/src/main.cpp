#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <LittleFS.h>

#define NR_OF_LEDS 3
int led[NR_OF_LEDS] = {D3,D2,D1};
bool led_status[NR_OF_LEDS] = {false};

const char* ssid = "FSSTistSuper";    // Name of the Access Point
const char* pass = "Ready4";          // must be >= 8 characters (at least for the ESP8266)!

IPAddress ip(192,168,4,1);            // should be 192.168.4.x
IPAddress gateway(192,168,4,1);       // should be 192.168.4.x
IPAddress subnet(255,255,255,0);
ESP8266WebServer server(80);          // WebServer server(80); for ESP8266

void handleRootFS();
void handleLEDRequest(bool);
void toggleLED();
void getLEDstatus();

void setup(){
  for (int i = 0; i < 3; i++) {
    pinMode(led[i], OUTPUT);
  }

  LittleFS.begin();

  WiFi.softAPConfig(ip, gateway, subnet);
  //WiFi.softAP(ssid, passwd);
  WiFi.softAP(ssid); // no passwd

  delay(500);

  server.on("/", HTTP_GET, handleRootFS);
  server.on("/toggleLED", HTTP_GET, toggleLED);
  server.on("/getLEDstatus", HTTP_GET, getLEDstatus);
  server.begin();

  Serial.begin(9600);
  Serial.println("Systemstart abgeschlossen");
}

void loop(){
  server.handleClient();
}

void handleRootFS() {
  Serial.println("handleRootFS");
  File file = LittleFS.open("/index.html", "r");
  if (file) {
    server.streamFile(file, "text/html");
    file.close();
  } else {
    server.send(500, "text/plain", "Internal Server Error");
  }
}

void handleLEDRequest(bool toggleLED) {
  Serial.printf("handleLEDRequest -> toggleLED=%d\n", toggleLED);
  if (server.hasArg("LEDID")) {
    int ledid = server.arg("LEDID").toInt();
    if (ledid < 0 || ledid > NR_OF_LEDS) {
      server.send(400, "text/plain", "Invalid LED ID");
    }

    if (toggleLED) {
      digitalWrite(led[ledid], !led_status[ledid]);
      led_status[ledid] = !led_status[ledid];
    }
    String returnString = (led_status[ledid]) ? "ON" : "OFF";
    server.send(200, "text/plain", returnString);
  } else {
    String data = server.arg("plain");
    server.send(400, "text/plain", data);
  }
}

void toggleLED() {
  handleLEDRequest(true);
}

void getLEDstatus() {
  handleLEDRequest(false);
}